

#Trabajando con un fichero donde se remplazo los puntos por blancos
bici<-read.table("usos_acumulados_clean.csv",header = TRUE, sep = ";")
bici[3,]
head(bici)
tail(bici)
summary(bici)
colnames(bici)

plot(bici$DIA,bici$Usos.bicis.total)
typeof(bici)
#obtener el tipo de dato
str(bici)

#Crear el campo Date que tiene formato "Date" del campo DIA
bici$Date<-as.Date(bici$DIA, "%d/%m/%Y")
head(bici)

plot(bici$Date,bici$Usos.bicis.total)
lines(bici$Date,bici$Usos.bicis.total)

#truncar la fecha a nivel de mes
plot(as.POSIXct(bici$Date,units = c("month")),bici$Usos.bicis.total)

#haciendo la transformaci�n con R
bici_2 <- read.csv("Tabla usos acumulados.csv",header=TRUE, sep=";", colClasses="character")
str(bici_2)
bici_2$Date<-as.Date(bici_2$DIA,"%d/%m/%Y")
head(bici_2)

sub_bici<-bici_2[,c("Date","Usos.bicis.total")]
str(sub_bici)

sub_bici[,"Usos.bicis.total"] <- lapply(sub_bici[,"Usos.bicis.total"],function(sub_bici){as.numeric(gsub(".", "", sub_bici))})

gsub(".", "", sub_bici$Usos.bicis.total)

sub_bici[,"Usos.bicis.total"]

