#------------------
#TAREAO AYTO
#------------

library(reshape2)
library(plyr)
library(lubridate)
#------
#Previamente modificique el fichero filtrando "€" y "."
#importar fichero cont_inscritos 2015.csv
insc_15<-read.table("cont_inscritos 2015_for.csv",header = T,sep = ";", dec = ",")

tmp<-insc_15[,c(4,20,23,24)]
colnames(tmp)
tmp$Presp<-tmp$PresupuestoTotal.IVAIncluido.
head(tmp)
#tmp<-tmp[,c(1,3)]
tmp$Aprobacion_Month<-ceiling_date(as.Date(tmp$FechaAprobaciónDerivado,"%d/%m/%Y"), "month")
tmp_1<-ddply(tmp,.(Organismo,Aprobacion_Month), summarise, total_presu=sum(Presp))

grepl("DISTRITO", tmp_1$Organismo)

subset(tmp_1, grepl("DISTRITO", tmp_1$Organismo)) 

#Filtrar El presuppuesto por distrito
tmp_1<-tmp_1[grepl("DISTRITO", tmp_1$Organismo),]

#por distrito
tmp_o<-ddply(tmp_1,.(Organismo), summarise, total_presu=sum(total_presu), rank = rank(-sum(total_presu), ties = "random"))

#RANK
tmp_o$rank<-rank(tmp_o$total_presu, ties = "random")
tmp_o

#por mes
tmp_m<-ddply(tmp_1,.(Aprobacion_Month), summarise, total_presu=sum(total_presu))
tmp_m<-tmp_m[order(tmp_m$Aprobacion_Month),]
plott(tmp_m$Aprobacion_Month,tmp_m$total_presu) #PLOT de evolusión del resupuesto
