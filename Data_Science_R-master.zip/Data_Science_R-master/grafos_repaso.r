
library(igraph)
library(reshape2)
library(plyr)

#Set wroking directory
setwd("C:/DS/Grafos")
#----karate----
# http://www.inside-r.org/packages/cran/igraph/docs/GML
k<-read.graph("data/karate.gml", format = c("gml"))
str(k)
plot(k, vertex.size = 0.3)

#aristas
k <- set.edge.attribute(k, name = "btw_e", E(k), 
                           edge.betweenness(k))
E(k)$btw_e


#para vertices 
k <- set.vertex.attribute(k, name = "btw_v", 
                             V(k), betweenness(k))
V(k)$btw_v
plot(k, vertex.size = (1 + V(k)$btw_v) / 10, edge.width=(1+E(k)$btw_e)/10)


#---------AMAZON-------
amazon <- readLines("data/com-amazon.top5000.cmty.txt")
amazon<-strsplit(amazon,"\t")
from=unlist(lapply(amazon,function(x) rep(x[1],length(x)-1))) # establish first column of edgelist by replicating the 1st element (=ID number) by the length of the line minus 1 (itself)
to=unlist(lapply(amazon,"[",-1))
el=cbind(from,to)
head(el)



#Plot del grafo completo
plot(g.el, vertex.label = NA, vertex.size = 0.3)

#CALCULO DE ATRIBUTOS 
g.el <- set.vertex.attribute(g.el, name = "btw_v", V(g.el), betweenness(g.el))
g.el <- set.vertex.attribute(g.el, name = "dee_v", V(g.el), degree(g.el))
?set.vertex.attribute
?betweenness

#PLOT DEL GRAFO DE ACUERDO A LOS ATRIBUTOS
g.sub <- induced_subgraph(g.el, V(g.el)$dee_v>=100)
plot(g.sub, vertex.label = NA, vertex.size = 0.3, edge.width=0.1)
plot(g.sub, vertex.size = (1+V(g.el)$btw_v/3000), edge.width=0.1)

plot(g.sub, layout = my_layout, vertex.label = NA, vertex.size = 0.3)


#TOP PRODUCTS
str(df.el)
df.el<-data.frame(el)

t.el<-table(df.el$from)
t.el<-melt(t.el)
t.el<-data.frame(t.el)
t.el$value<-as.numeric(t.el$value)
t.el<-t.el[order(-t.el$value),]

TOP_PROD<-head(t.el,10)
TOP_PROD


#layout m�s reducido, restringiendo a nosodos con m�s de 3 salidas
n<-table(el[,1])
id<-unique(el[,1])
n.el=cbind(id,n)
n.el<-data.frame(n.el)
n.el$n<-as.numeric(n.el$n)
s.el<-subset(n.el,n>=3)
head(n.el)
str(n.el)

top<-s.el[order(-s.el$n),]
top

#metodo para trabajar con adjlist.
graph.adjlist(adjlist, mode = c("out", "in", "all", "total"),
              duplicate = TRUE)